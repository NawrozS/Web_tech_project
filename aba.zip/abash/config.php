<?php

$conn= mysqli_connect('localhost','root','','abash');

//Write at least 2 functions for open and close connection to database.
?>