<!DOCtype html>
<html>
 <head>
 <meta charset="utf-8">
 <title>team member</title>
 <link rel="stylesheet" href="css/style.css">
 <link rel="stylesheet" href="css/style_2.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">  
</head>
 <body>
 <!-- Menu -->
	 <div class="logo_menu">
	    <div class="neon">
		    <img src="img/logo.png">
	    </div>
	
		<ul class="main-nav">
		    <li><a href="index.php">Home</a></li>
			<li class="active"><a href="about.php">About</a></li>
			<li><a href="#contact">Contuct us</a></li>
			<li><a href="post.php">Post ad</a></li>
			<li><a href="login.php">Login</a></li>
			
		</ul>
	</div>
 <br/> <br/> <br/> <br/> <br/>
 
  <div class="team-member">
   <h1> our team</h1>
   <br/><br/>
   <span class="border"></span>
    <p>
  <div class="ps">
    
    <a href="#1"><img src="img/t_1.jpg" alt=""></a>
    <a href="#2"><img src="img/t_2.jpg" alt=""></a>
    <a href="#3"><img src="img/t_3.jpg" alt=""></a>
    <a href="#4"><img src="img/t_4.jpg" alt=""></a>
    <a href="#5"><img src="img/t_5.jpg" alt=""></a>
 </div>
 <div class="section" id="1">
 <span class="name">Raihun,Ahif:</span>
 <span class="border"></span><br>
 <p>
  mane:raihun,ashif.our project is about house rent and officespace .
  one this project i work about the frontend and the design of this website.html css 
 </p>
 <br>
 </div>
 <div class="section" id="2">
 <span class="name">islam.MD Mariful:</span>
 <span class="border"></span><br>
 <p>
 Back-end developers work hand-in-hand with front-end developers by providing the outward facing web application elements server-side logic. In other words, backend developers create the logic to make the web app function properly, and they accomplish this through the use of server-side scripting languages like Ruby or PHP
 </p>
 </div>
  </div>
 <div class="section" id="3">
 <span class="name">noraz:</span>
 <span class="border"></span>
 <p>
    
 </p>
 </div>
  </div>
 <div class="section" id="4">
 <span class="name">islam.MD Mariful</span>
 <span class="border"></span>
 <p>
 </p>
 </div>
  </div>
 <div class="section" id="5">
 <span class="name">islam.MD Mariful:</span>
 <span class="border"></span>
 <p>
     strwegiuewgr
 </p>
 </div>

 
</body>
<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
<!-- Bottom -->
	<footer class="footer">
		
	<ul>
		<li>
		<div>
			<img src="img/logo.png">	
		</div>
		<div>
			<font face="serif" size="4" color="skyblue">Follow us:</font>
			<a href="#" class="call"><i class="fa fa-facebook-f" style="font-size:30px;width:23px;background-color:black;color:white;padding-right: 15px"></i></a>
			<a href="#" class="call"><i class="fa fa-google" style="font-size:30px;background-color:black;color:white;padding-right: 12px"></i></a>
			<a href="#" class="call"><i class="fa fa-twitter" style="font-size:30px;background-color:black;color:white;padding-right: 9px"></i></a>

		</div>
       </li>
	   <li>
		<div class="contact">
			<h1><a name="contact"></a>Contact With Us</h1><br>
			<p>Phone No: 0175263939</p><br>
			<p>Email: abash.bd@gmail.com</p>

		</div>
       </li>
	   
	</ul>
		
	</footer>


</html>